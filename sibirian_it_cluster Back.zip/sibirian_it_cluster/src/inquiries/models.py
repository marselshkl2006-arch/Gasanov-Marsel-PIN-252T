from django.db import models
from django.contrib.auth import get_user_model
from manufacturers.models import Manufacturer
from products.models import Product

User = get_user_model()

class Inquiry(models.Model):
    STATUS_CHOICES = (
        ('new', 'Новый'),
        ('in_progress', 'В обработке'),
        ('completed', 'Завершен'),
        ('cancelled', 'Отменен'),
    )
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='inquiries')
    manufacturer = models.ForeignKey(Manufacturer, on_delete=models.CASCADE, related_name='inquiries')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')
    message = models.TextField(blank=True, null=True, verbose_name='Сообщение')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Запрос'
        verbose_name_plural = 'Запросы'
        ordering = ['-created_at']

    def __str__(self):
        return f"Запрос #{self.id} от {self.user.username}"

class InquiryItem(models.Model):
    inquiry = models.ForeignKey(Inquiry, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='inquiry_items')
    quantity = models.PositiveIntegerField(default=1, verbose_name='Количество')
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name='Цена за единицу')

    class Meta:
        verbose_name = 'Позиция запроса'
        verbose_name_plural = 'Позиции запроса'

    def __str__(self):
        return f"{self.product.name} x {self.quantity}"