from django.contrib import admin
from .models import Inquiry, InquiryItem

# Пока оставим пустым