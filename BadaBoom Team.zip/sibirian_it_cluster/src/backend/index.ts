export interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  specifications: Record<string, string>; // { "Вес": "10кг", "Материал": "Сталь" }
  images: string[];
  manufacturerId: string;
}

export interface Manufacturer {
  id: string;
  name: string;
  description: string;
  logo: string;
  coverImage: string;
  contacts: {
    phone: string;
    email: string;
    website?: string;
    address: string;
    requisites: string; // Реквизиты
  };
  certifications: string[]; // Ссылки на изображения сертификатов
}
