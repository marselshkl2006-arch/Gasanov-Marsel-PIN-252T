from rest_framework import viewsets, permissions, filters
from django_filters.rest_framework import DjangoFilterBackend
from .models import Manufacturer, Certificate
from .serializers import ManufacturerSerializer, CertificateSerializer

class ManufacturerViewSet(viewsets.ModelViewSet):
    queryset = Manufacturer.objects.all()
    serializer_class = ManufacturerSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'description', 'country']
    filterset_fields = ['country', 'is_verified']
    ordering_fields = ['name', 'created_at']
    
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [permissions.IsAuthenticated()]
        return [permissions.AllowAny()]

class CertificateViewSet(viewsets.ModelViewSet):
    serializer_class = CertificateSerializer
    
    def get_queryset(self):
        return Certificate.objects.filter(manufacturer_id=self.kwargs['manufacturer_pk'])
    
    def perform_create(self, serializer):
        manufacturer = Manufacturer.objects.get(pk=self.kwargs['manufacturer_pk'])
        serializer.save(manufacturer=manufacturer)