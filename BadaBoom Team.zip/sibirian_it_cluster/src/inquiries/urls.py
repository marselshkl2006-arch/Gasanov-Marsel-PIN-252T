from django.urls import path, include
from rest_framework import routers
from . import views

router = routers.DefaultRouter()
# Добавьте basename явно
router.register(r'inquiries', views.InquiryViewSet, basename='inquiry')

urlpatterns = [
    path('', include(router.urls)),
]