from django.contrib import admin
from .models import Manufacturer, Certificate

@admin.register(Manufacturer)
class ManufacturerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'country', 'is_verified', 'created_at')
    list_filter = ('country', 'is_verified', 'created_at')
    search_fields = ('name', 'email', 'inn')

@admin.register(Certificate)
class CertificateAdmin(admin.ModelAdmin):
    list_display = ('name', 'manufacturer', 'issued_by', 'issued_date', 'valid_until')
    list_filter = ('issued_date', 'valid_until')
    search_fields = ('name', 'manufacturer__name', 'issued_by')