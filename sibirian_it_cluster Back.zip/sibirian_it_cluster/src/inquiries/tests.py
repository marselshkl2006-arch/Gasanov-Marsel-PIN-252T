from django.test import TestCase

# Пока оставим пустым