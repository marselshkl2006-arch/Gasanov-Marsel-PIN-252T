from django.contrib import admin
from .models import ProductCategory, Product, ProductAttribute, ProductAttributeValue

# Пока оставим пустым, можно будет добавить позже