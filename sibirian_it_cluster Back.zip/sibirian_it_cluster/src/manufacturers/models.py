from django.db import models
from django.contrib.auth import get_user_model
from django_countries.fields import CountryField

User = get_user_model()

class Manufacturer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='manufacturer')
    name = models.CharField(max_length=255, verbose_name='Название компании')
    description = models.TextField(verbose_name='Описание компании')
    logo = models.ImageField(upload_to='manufacturers/logos/', blank=True, null=True, verbose_name='Логотип')
    header_background = models.ImageField(upload_to='manufacturers/headers/', blank=True, null=True, verbose_name='Фон шапки')
    primary_color = models.CharField(max_length=7, default='#3B82F6', verbose_name='Основной цвет')
    secondary_color = models.CharField(max_length=7, default='#10B981', verbose_name='Дополнительный цвет')
    
    # Контактная информация
    email = models.EmailField(verbose_name='Email')
    phone = models.CharField(max_length=20, verbose_name='Телефон')
    website = models.URLField(blank=True, null=True, verbose_name='Веб-сайт')
    address = models.TextField(verbose_name='Адрес')
    country = CountryField(verbose_name='Страна')
    
    # Реквизиты
    inn = models.CharField(max_length=12, verbose_name='ИНН')
    kpp = models.CharField(max_length=9, blank=True, null=True, verbose_name='КПП')
    ogrn = models.CharField(max_length=13, verbose_name='ОГРН')
    bank_name = models.CharField(max_length=255, verbose_name='Название банка')
    bank_account = models.CharField(max_length=20, verbose_name='Расчетный счет')
    corr_account = models.CharField(max_length=20, verbose_name='Корреспондентский счет')
    bik = models.CharField(max_length=9, verbose_name='БИК')
    
    is_verified = models.BooleanField(default=False, verbose_name='Проверенный производитель')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Производитель'
        verbose_name_plural = 'Производители'
        ordering = ['name']

    def __str__(self):
        return self.name


class Certificate(models.Model):
    manufacturer = models.ForeignKey(Manufacturer, on_delete=models.CASCADE, related_name='certificates')
    name = models.CharField(max_length=255, verbose_name='Название сертификата')
    file = models.FileField(upload_to='manufacturers/certificates/', verbose_name='Файл сертификата')
    issued_by = models.CharField(max_length=255, verbose_name='Кем выдан')
    issued_date = models.DateField(verbose_name='Дата выдачи')
    valid_until = models.DateField(blank=True, null=True, verbose_name='Действителен до')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Сертификат'
        verbose_name_plural = 'Сертификаты'
        ordering = ['-issued_date']

    def __str__(self):
        return f"{self.name} - {self.manufacturer.name}"