from rest_framework import serializers
from .models import Inquiry, InquiryItem

class InquiryItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    
    class Meta:
        model = InquiryItem
        fields = '__all__'

class InquirySerializer(serializers.ModelSerializer):
    items = InquiryItemSerializer(many=True, read_only=True)
    user_name = serializers.CharField(source='user.username', read_only=True)
    manufacturer_name = serializers.CharField(source='manufacturer.name', read_only=True)
    
    class Meta:
        model = Inquiry
        fields = '__all__'