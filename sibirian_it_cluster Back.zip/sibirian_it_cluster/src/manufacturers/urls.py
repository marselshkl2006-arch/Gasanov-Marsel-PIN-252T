from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'manufacturers', views.ManufacturerViewSet)
router.register(r'manufacturers/(?P<manufacturer_pk>[^/.]+)/certificates', 
                views.CertificateViewSet, 
                basename='manufacturer-certificates')

urlpatterns = [
    path('', include(router.urls)),
]