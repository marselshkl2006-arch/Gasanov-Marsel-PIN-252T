from django.test import TestCase
from django.contrib.auth import get_user_model
from .models import Manufacturer

User = get_user_model()

class ManufacturerTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        
    def test_create_manufacturer(self):
        manufacturer = Manufacturer.objects.create(
            user=self.user,
            name='Test Manufacturer',
            description='Test Description',
            email='test@test.com',
            phone='1234567890',
            address='Test Address',
            country='RU',
            inn='123456789012',
            ogrn='1234567890123',
            bank_name='Test Bank',
            bank_account='12345678901234567890',
            corr_account='12345678901234567890',
            bik='123456789'
        )
        self.assertEqual(manufacturer.name, 'Test Manufacturer')