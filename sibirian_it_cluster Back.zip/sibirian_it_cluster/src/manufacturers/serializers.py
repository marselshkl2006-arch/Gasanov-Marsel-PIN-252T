from rest_framework import serializers
from .models import Manufacturer, Certificate

class CertificateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Certificate
        fields = '__all__'

class ManufacturerSerializer(serializers.ModelSerializer):
    certificates = CertificateSerializer(many=True, read_only=True)
    
    class Meta:
        model = Manufacturer
        fields = '__all__'
        read_only_fields = ('user', 'created_at', 'updated_at')