from django.apps import AppConfig

class ManufacturersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'manufacturers'
    verbose_name = 'Производители'